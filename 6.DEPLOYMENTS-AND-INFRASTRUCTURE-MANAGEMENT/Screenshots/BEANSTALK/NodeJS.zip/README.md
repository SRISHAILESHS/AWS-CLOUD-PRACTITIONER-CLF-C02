# Node.js Deployment using AWS Elastic Beanstalk

## Files
- `app.js`: Express web application
- `package.json`: Application metadata, start command, and dependency

## Local testing
Install Node.js, open a terminal in this folder, and run:

```bash
npm install
npm start
```

Open http://localhost:8080
Health endpoint: http://localhost:8080/health

## Deploy to AWS Elastic Beanstalk
1. Open the AWS Elastic Beanstalk console.
2. Create a Web server environment using a supported Node.js platform.
3. Upload the ZIP file containing `app.js` and `package.json` at the ZIP root.
4. Wait for deployment and check environment health.
5. Open the environment URL.

AWS resources used by the environment may incur charges.
