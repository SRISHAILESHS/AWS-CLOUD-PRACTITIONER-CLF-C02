const express = require("express");

const app = express();
const PORT = process.env.PORT || 8080;

app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>My AWS Node.js App</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            text-align: center;
            padding: 60px 20px;
          }
          .card {
            background: white;
            padding: 35px;
            max-width: 550px;
            margin: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px #00000015;
          }
          h1 {
            color: #e47911;
          }
          p {
            color: #334155;
          }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Welcome to AWS Elastic Beanstalk!</h1>
          <h2>Node.js Application is Running</h2>
          <p>Your application is deployed on AWS.</p>
          <p>Service: Elastic Beanstalk</p>
          <p>Runtime: Node.js</p>
        </div>
      </body>
    </html>
  `);
});

app.get("/health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    application: "Beanstalk-NodeJS"
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});
